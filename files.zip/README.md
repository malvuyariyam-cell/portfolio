# 🎨 Digital Creator Portfolio Website

A modern, stylish portfolio website for freelance digital creators. Features a bold black background with yellow accents, smooth animations, and a fully functional contact form.

## ✨ Features

- **Modern Design**: Bold typography, yellow accent colors, smooth animations
- **Fully Responsive**: Looks great on desktop, tablet, and mobile
- **Contact Form**: Functional form to collect client inquiries
- **Portfolio Grid**: Showcase your best work
- **Service Cards**: Highlight what you offer with hover effects
- **Smooth Scrolling**: Professional navigation experience

## 📁 File Structure

```
portfolio-website/
│
├── index.html          # Main HTML file
├── styles.css          # All styling and animations
├── script.js           # JavaScript functionality
└── README.md           # This file
```

## 🚀 How to Upload & Launch Your Website

### Option 1: GitHub Pages (FREE & Easiest)

1. **Create a GitHub account** at github.com
2. **Create a new repository** named `your-username.github.io`
3. **Upload your files**:
   - Click "Add file" → "Upload files"
   - Drag and drop `index.html`, `styles.css`, and `script.js`
   - Click "Commit changes"
4. **Your site is live!** Visit `https://your-username.github.io`

**Pros**: Free, easy, fast
**Cons**: Public repository, limited customization

---

### Option 2: Netlify (FREE & Recommended)

1. **Go to netlify.com** and sign up
2. **Drag and drop** your folder into Netlify
3. **Your site is live!** Netlify gives you a URL like `your-site.netlify.app`
4. **Optional**: Connect a custom domain (yourname.com)

**Pros**: Free, automatic HTTPS, easy updates, custom domains
**Cons**: None really!

---

### Option 3: Vercel (FREE & Fast)

1. **Go to vercel.com** and sign up
2. **Import your project** from GitHub or upload files
3. **Deploy!** Get a URL like `your-site.vercel.app`

**Pros**: Super fast, free, great for beginners
**Cons**: Requires GitHub (recommended anyway)

---

### Option 4: Traditional Web Hosting

If you want your own domain (like `yourname.com`):

1. **Buy a domain** from Namecheap, GoDaddy, or Google Domains ($10-15/year)
2. **Get hosting** from Hostinger, Bluehost, or SiteGround ($3-10/month)
3. **Upload via FTP**:
   - Use FileZilla (free FTP client)
   - Connect with credentials from your host
   - Upload all files to `public_html` folder
4. **Visit your domain!**

**Pros**: Professional domain, full control
**Cons**: Costs money, requires more setup

---

## 💾 How to Connect the Contact Form

Your form currently shows a demo message. Here's how to make it actually save data:

### 🔥 RECOMMENDED: Firebase (Easiest)

**Step 1**: Set up Firebase

1. Go to [firebase.google.com](https://firebase.google.com)
2. Click "Get Started" → "Add Project"
3. Name your project (e.g., "portfolio-contact-form")
4. Disable Google Analytics (not needed)
5. Click "Create Project"

**Step 2**: Enable Firestore Database

1. In Firebase Console, click "Firestore Database"
2. Click "Create Database"
3. Select "Start in production mode"
4. Choose a location close to you
5. Click "Enable"

**Step 3**: Get your Firebase config

1. Click the gear icon → "Project Settings"
2. Scroll down to "Your apps"
3. Click the web icon `</>`
4. Register your app (name it anything)
5. **Copy the firebaseConfig object**

**Step 4**: Add Firebase to your website

Open `index.html` and add these scripts **before** `<script src="script.js"></script>`:

```html
<!-- Firebase Scripts -->
<script src="https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore-compat.js"></script>
<script>
  // Your Firebase configuration (paste from Firebase Console)
  const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
  };
  
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const db = firebase.firestore();
</script>
<script src="script.js"></script>
```

**Step 5**: Update the form handler

Open `script.js` and find this section (around line 95):

```javascript
// TEMPORARY: Show success message (replace with real backend)
showMessage('success', 'Message sent successfully! (Demo mode)');
```

**Replace it with**:

```javascript
// Save to Firebase Firestore
try {
    await db.collection('contacts').add(formData);
    showMessage('success', 'Message sent successfully! I\'ll get back to you within 24 hours.');
    contactForm.reset();
} catch (error) {
    console.error('Error:', error);
    showMessage('error', 'Something went wrong. Please try again or email me directly.');
}
```

**Step 6**: View your form submissions

1. Go to Firebase Console → Firestore Database
2. You'll see a `contacts` collection with all submissions
3. Each submission shows: name, email, phone, service, budget, description, timestamp

**Done!** Your form now saves all client inquiries to Firebase. ✅

---

### 📊 ALTERNATIVE: Google Sheets (Also Easy)

If you prefer seeing submissions in a spreadsheet:

**Step 1**: Create a Google Sheet

1. Go to [sheets.google.com](https://sheets.google.com)
2. Create a new sheet
3. Name the first row: `Timestamp | Name | Email | Phone | Service | Budget | Description`

**Step 2**: Create Apps Script

1. In your sheet, go to **Extensions** → **Apps Script**
2. Delete any existing code
3. Paste this:

```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  
  sheet.appendRow([
    new Date(),
    data.fullName,
    data.email,
    data.phone,
    data.service,
    data.budget,
    data.projectDescription
  ]);
  
  return ContentService.createTextOutput(JSON.stringify({success: true}))
    .setMimeType(ContentService.MimeType.JSON);
}
```

4. Click **Save** (disk icon)
5. Click **Deploy** → **New deployment**
6. Click **Select type** → **Web app**
7. Set:
   - Description: "Contact Form Handler"
   - Execute as: "Me"
   - Who has access: "Anyone"
8. Click **Deploy**
9. **Copy the Web app URL** (looks like `https://script.google.com/macros/s/...`)

**Step 3**: Update your form

Open `script.js` and replace the temporary success message with:

```javascript
// Send to Google Sheets
fetch('YOUR_GOOGLE_APPS_SCRIPT_URL', {
    method: 'POST',
    body: JSON.stringify(formData)
})
.then(response => response.json())
.then(data => {
    showMessage('success', 'Message sent successfully! I\'ll get back to you soon.');
    contactForm.reset();
})
.catch(error => {
    console.error('Error:', error);
    showMessage('error', 'Something went wrong. Please try again.');
});
```

**Replace** `'YOUR_GOOGLE_APPS_SCRIPT_URL'` with the URL you copied.

**Done!** Form submissions now appear in your Google Sheet. ✅

---

## ✏️ How to Edit Your Website

### Change Text Content

Open `index.html` and find what you want to change:

**Your Name & Branding**:
```html
<!-- Line 22 -->
<div class="logo">DIGITAL<span class="accent">CREATOR</span></div>

<!-- Change to: -->
<div class="logo">YOUR<span class="accent">NAME</span></div>
```

**Main Headline**:
```html
<!-- Line 44-47 -->
<span class="title-line">I BUILD WEBSITES</span>
<span class="title-line">THAT MAKE YOU</span>
<span class="title-line accent-text">MONEY.</span>

<!-- Change to your headline -->
```

**About Section**:
```html
<!-- Line 62-64 -->
<p class="about-description">
    I'm a freelance creator who builds modern websites...
</p>

<!-- Update with your bio -->
```

**Services**:
```html
<!-- Lines 85-150 -->
<!-- Edit service titles, descriptions, and bullet points -->
```

**Contact Email & Social Media**:
```html
<!-- Line 245 & 251 -->
<span>your.email@example.com</span>
<span>@yourusername</span>

<!-- Update with your real info -->
```

**Footer**:
```html
<!-- Line 339 -->
<p>© 2026 Your Name – All Rights Reserved</p>
```

---

### Change Colors

Open `styles.css` and edit the color variables (lines 6-10):

```css
:root {
    --color-bg: #000000;        /* Background color */
    --color-text: #ffffff;      /* Text color */
    --color-accent: #FFD700;    /* Yellow accent - CHANGE THIS */
    --color-gray: #808080;      /* Gray text */
    --color-gray-dark: #333333; /* Card backgrounds */
}
```

**Color Ideas**:
- Electric Blue: `#00D9FF`
- Hot Pink: `#FF006B`
- Neon Green: `#00FF88`
- Purple: `#9D4EDD`
- Orange: `#FF6B00`

---

### Add Project Images

Replace the placeholder project cards with real images:

1. **Save your project images** as: `project1.jpg`, `project2.jpg`, etc.
2. **Upload them** to your website folder
3. **In `index.html`**, find the project placeholder (line 187):

```html
<div class="project-placeholder">
    <span>PROJECT IMAGE</span>
</div>
```

**Replace with**:
```html
<img src="project1.jpg" alt="Project Name" style="width: 100%; height: 100%; object-fit: cover;">
```

Repeat for all 4 projects.

---

### Change Fonts

The website uses **Bebas Neue** (headings) and **Archivo** (body text).

To change fonts:

1. Go to [Google Fonts](https://fonts.google.com)
2. Pick your fonts
3. Copy the `<link>` code
4. **Replace line 11** in `index.html`:

```html
<!-- Current fonts -->
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Archivo:wght@400;600;700&display=swap" rel="stylesheet">

<!-- Replace with your fonts -->
```

5. **Update `styles.css` line 14-15**:

```css
--font-display: 'Bebas Neue', sans-serif;
--font-body: 'Archivo', sans-serif;

<!-- Change to your fonts -->
```

---

## 📱 Testing on Mobile

1. **Open on your phone**: Just visit your website URL
2. **Use Chrome DevTools**:
   - Right-click → "Inspect"
   - Click the phone icon (top-left)
   - Test different screen sizes

---

## 🎯 Next Steps to Improve Your Portfolio

1. **Add Real Project Images**: Replace placeholders with your work
2. **Write Better Copy**: Update the About section with your unique story
3. **Add Testimonials**: Client reviews build trust
4. **Include Pricing**: Help clients know what to expect
5. **Add Analytics**: Use Google Analytics to track visitors
6. **SEO Optimization**: Add meta descriptions, alt tags for images
7. **Custom Domain**: Get `yourname.com` for $10-15/year

---

## 🐛 Troubleshooting

**Form not submitting?**
- Check browser console (F12) for errors
- Make sure Firebase is initialized properly
- Verify your Apps Script URL is correct

**Website looks broken?**
- Make sure all 3 files are in the same folder
- Check that filenames are exactly: `index.html`, `styles.css`, `script.js`
- Clear your browser cache (Ctrl+Shift+R)

**Not responsive on mobile?**
- Make sure you have the viewport meta tag (line 5 in HTML)
- Test different screen sizes in Chrome DevTools

---

## 💡 Tips for Success

1. **Update Regularly**: Add new projects as you complete them
2. **Get Feedback**: Ask friends what they think
3. **Speed Matters**: Compress images before uploading
4. **Backup Your Files**: Keep copies on Google Drive or GitHub
5. **Track Results**: See which pages get the most views

---

## 📞 Need Help?

If you get stuck:
1. Check the browser console for error messages (F12)
2. Google the error message
3. Ask on Stack Overflow or Reddit r/webdev
4. Watch YouTube tutorials for your specific hosting platform

---

## 🎨 Want More Features?

Let me know if you'd like me to add:
- Pricing packages section
- Client testimonials carousel
- Blog section
- Image gallery lightbox
- Email marketing integration
- Payment integration (Stripe, PayPal)
- Project filters (filter by category)
- Dark/Light mode toggle

---

**Good luck with your portfolio! 🚀**

Remember: Your portfolio is your digital storefront. Keep it updated, make it personal, and let your work speak for itself!
